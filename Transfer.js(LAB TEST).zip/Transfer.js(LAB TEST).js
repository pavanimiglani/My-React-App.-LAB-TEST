import React, { useState } from 'react';
import Receipt from './Receipt'; 

const Transfer = () => {
  // Mock transaction data (you can replace this with real data)
  const transactionData = {
    transactionID: '07031995',
    date: '2023-10-13',
    amount: '$10000.00',
    sender: 'Pavani Miglani',
    receiver: 'Dhiraj Miglani',
  }; 

  const [showReceipt, setShowReceipt] = useState(false);

  const handleSubmit = () => {
    setShowReceipt(!showReceipt); // Toggle the visibility
  };
 
  return (
    <div className="transfer">
      <h1>Transfer Funds</h1>
      <button onClick={handleSubmit}>Submit</button>
      {showReceipt && <Receipt transactionData={transactionData} />}
    </div>
  );
};

export default Transfer; 

