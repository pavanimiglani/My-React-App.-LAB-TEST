
import React from 'react';
import AmountInput from './AmountInput'; // Make sure the import path is correct
import Transfer from './Transfer';
import AmountInputForm from './components/AmountInputForm'; // Import the component

function App() {
  return (
    <div className="App">
      <AmountInputForm /> {/* Render the component with styles */}
    </div>
  );
} 



function App() {
  return (
    <div className="App">
      <h1>Money Transfer App</h1>
      <AmountInput />
      <Transfer />
    </div>
  );
}

export default App;


