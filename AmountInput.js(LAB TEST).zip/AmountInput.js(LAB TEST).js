import React, { Component } from 'react';

class AmountInput extends Component {
  constructor(props) {
    super(props);
    this.state = {
      amount: 0,
    };
  }

  handleAmountChange = (event) => {
    const newValue = event.target.value;
    this.setState({ amount: newValue });
  }; 

  render() {
    return (
      <div>
        <h1>Amount Input</h1>
        <input
          type="number"
          value={this.state.amount}
          onChange={this.handleAmountChange}
        />
        <p>Entered Amount: {this.state.amount}</p>
      </div>
    );
  }
}

export default AmountInput;
