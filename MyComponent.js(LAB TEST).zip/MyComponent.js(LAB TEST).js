
import React, { Component } from 'react';

class MyComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      amount: 0,
    };
    this.sourceAccount = '12022002';
    this.destinationAccount = '07031995';
  }

  handleAmountChange = (event) => {
    this.setState({ amount: event.target.value });
  };

  handleSubmit = (event) => {
    event.preventDefault();
    console.log('Amount submitted: ' + this.state.amount);
  };

  render() {
    return (
      <div>
        <h1>Source Account: {this.sourceAccount}</h1>
        <h1>Destination Account: {this.destinationAccount}</h1>

        <form onSubmit={this.handleSubmit}>
          <label>
            Enter Amount:
            <input
              type="number"
              value={this.state.amount}
              onChange={this.handleAmountChange}
            />
          </label>
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default MyComponent;
